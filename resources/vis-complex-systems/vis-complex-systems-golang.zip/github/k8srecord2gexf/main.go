/*
  This code is part of the L&D work and tech talk "Beyond Dashboards - Visualising Complex Systems" by Andy Burgin - Sky Betting and Gaming
  https://sbg.technology/2020/04/28/vis-complex-systems/
*/
package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strings"
	time "time"
)

type genericResource struct {
	Uid       string
	Name      string
	Namespace string
}

// edge node and interval definitions
type node struct {
	Uid        string
	Name       string
	Kind       string
	Namespace  string
	intervals  []interval
	cpuMetrics []metricInterval
	memMetrics []metricInterval
}

type edge struct {
	SrcUid    string
	TgtUid    string
	SrcName   string
	TgtName   string
	Namespace string
	Kind      string
	intervals []interval
}

type interval struct {
	start time.Time
	end   time.Time
}

type metricInterval struct {
	start  time.Time
	end    time.Time
	metric string
}

// UPDATE metric event
type UpdateMetric struct {
	Uid       string
	Name      string
	Kind      string
	Namespace string
	CpuUsage  string
	MemUsage  string
}

var (
	nodes   []node
	edges   []edge
	lastEnd time.Time
)

func main() {

	// TODO pass file name via command line param
	file, err := os.Open("recorder.log")
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	// process each line
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		processRecord(scanner.Text())
	}

	// close open intervals
	setIntervalEnd(lastEnd)

	// TODO pass file name via command line param
	writeGEXF("test.gexf")

	log.Println("Done.")
}

func processRecord(line string) {

	s := strings.Split(line, ",")

	//extract date
	layout := "2006/01/02 15:04:05"
	t, err := time.Parse(layout, s[0][0:19])
	if err != nil {
		log.Fatal(err)
	}
	lastEnd = t

	//extract action
	a := s[0][20:len(s[0])]

	//extract kind
	k := s[1]

	//extract json data
	j := strings.Join(s[2:], ",")

	//fmt.Printf("%v - %v - %v - %v\n", t, a, k, j)
	if a == "ADD" {
		if k != "Relationship" {
			addNode(t, a, k, j)
		} else {
			addEdge(t, a, j)
		}
	}

	if a == "DELETE" {
		if k != "Relationship" {
			deleteNode(t, a, k, j)
		} else {
			deleteEdge(t, a, j)
		}
	}

	if a == "UPDATE" {
		if k == "Pod" {
			updateNodeMetrics(t, a, k, j)
		}
	}
}

func addNode(t time.Time, a string, k string, j string) {
	log.Println("addNode")

	var res genericResource
	bytes := []byte(j)
	json.Unmarshal(bytes, &res)
	log.Printf("resource ID %v", res.Uid)

	// check we've not seen it before
	for _, existingNode := range nodes {
		if existingNode.Uid == res.Uid {
			log.Fatal("Error node already exists " + k + " " + res.Name + " " + res.Uid)
		}
	}

	// add node to nodes slice
	var newNode node
	newNode.Uid = res.Uid
	newNode.Name = res.Name
	newNode.Kind = k
	newNode.Namespace = res.Namespace
	// add interval stating at t - endtime will be fixed at end of app run or when node is deleted
	newNode.intervals = append(newNode.intervals, interval{t, time.Unix(0, 0)})

	nodes = append(nodes, newNode)
}

func addEdge(t time.Time, a string, j string) {
	log.Println("addEdge")

	var res edge
	bytes := []byte(j)
	json.Unmarshal(bytes, &res)

	// have seen it before ?
	existingRelationshipIdx := -1
	for i, edge := range edges {
		if edge.SrcUid == res.SrcUid && edge.TgtUid == res.TgtUid {
			existingRelationshipIdx = i
		}
	}

	// seen the relationship ?
	if existingRelationshipIdx != -1 {
		// no endtime set on the latest latest interval, that shouldn't happen, consider the new relationship a continuation of this one
		if edges[existingRelationshipIdx].intervals[len(edges[existingRelationshipIdx].intervals)-1].end == time.Unix(0, 0) {
			log.Printf("existing relationship with no interval end set %v\n", edges[existingRelationshipIdx])
			return
		} else {
			// existing relationship with a closed interval, add new interval to it below
		}
	} else {
		// new relationship, add it and start a new interval
		log.Printf("new relationship\n")
		edges = append(edges, res)
		existingRelationshipIdx = len(edges) - 1
	}

	// add interval - endtime will be fixed at end of app run or when edge is removed
	edges[existingRelationshipIdx].intervals = append(edges[existingRelationshipIdx].intervals, interval{t, time.Unix(0, 0)})
}

func updateNodeMetrics(t time.Time, a string, k string, j string) {
	log.Printf("updateNodeMetrics %v\n", j)

	var res UpdateMetric
	bytes := []byte(j)
	json.Unmarshal(bytes, &res)

	// seen it before ?
	nodeFound := false
	for i, node := range nodes {
		// finish any existing metrics enitervals, add new one, endtime fixed at end of app run or when metrics are updated
		if node.Uid == res.Uid {
			// close last cpumetric interval
			if len(node.cpuMetrics) > 0 {
				node.cpuMetrics[len(node.cpuMetrics)-1].end = t
			}
			nodes[i].cpuMetrics = append(nodes[i].cpuMetrics, metricInterval{t, time.Unix(0, 0), res.CpuUsage})
			// close last memmetric interval
			if len(node.memMetrics) > 0 {
				node.memMetrics[len(node.memMetrics)-1].end = t
			}
			nodes[i].memMetrics = append(nodes[i].memMetrics, metricInterval{t, time.Unix(0, 0), res.MemUsage})
			nodeFound = true
		}
	}
	if !nodeFound {
		log.Printf("WARNING: node not found%v\n", res)
	}
}

func deleteNode(t time.Time, a string, k string, j string) {
	log.Println("deleteNode")

	var res node
	bytes := []byte(j)
	json.Unmarshal(bytes, &res)

	// search for node, set endtim for intervals and metric intervals
	nodeFound := false
	for _, node := range nodes {
		if node.Uid == res.Uid {
			node.intervals[len(node.intervals)-1].end = t
			if len(node.cpuMetrics) > 0 {
				node.cpuMetrics[len(node.cpuMetrics)-1].end = t
			}
			if len(node.memMetrics) > 0 {
				node.memMetrics[len(node.cpuMetrics)-1].end = t
			}
			nodeFound = true
		}
	}
	if !nodeFound {
		log.Printf("WARNING: node not found%v\n", res)
	}
}

func deleteEdge(t time.Time, a string, j string) {
	log.Println("deleteEdge")

	var res edge
	bytes := []byte(j)
	json.Unmarshal(bytes, &res)

	// find exiting relationship
	existingRelationshipIdx := -1
	for i, edge := range edges {
		if edge.SrcUid == res.SrcUid && edge.TgtUid == res.TgtUid {
			existingRelationshipIdx = i
		}
	}
	if existingRelationshipIdx == -1 {
		//TODO how to handle pending pods
		log.Printf("not existing relationship %v\n", res)
		return
	}

	// update endtime of edge interval
	edges[existingRelationshipIdx].intervals[len(edges[existingRelationshipIdx].intervals)-1].end = t
}

func setIntervalEnd(t time.Time) {
	log.Printf("setIntervalEnd()\n")

	// find node intervals and metrics without the endtime set
	for i, node := range nodes {
		//update interval endtime
		if node.intervals[len(node.intervals)-1].end == time.Unix(0, 0) {
			nodes[i].intervals[len(node.intervals)-1].end = t
		}
		// update cpu endtime
		if len(node.cpuMetrics) > 0 {
			if node.cpuMetrics[len(node.cpuMetrics)-1].end == time.Unix(0, 0) {
				nodes[i].cpuMetrics[len(node.cpuMetrics)-1].end = t
			}
		}
		if len(node.memMetrics) > 0 {
			if node.memMetrics[len(node.memMetrics)-1].end == time.Unix(0, 0) {
				nodes[i].memMetrics[len(node.memMetrics)-1].end = t
			}
		}
	}

	// find edge intervals without the endtime set
	for i, edge := range edges {
		//update interval endtime
		if edge.intervals[len(edge.intervals)-1].end == time.Unix(0, 0) {
			edges[i].intervals[len(edge.intervals)-1].end = t
		}
	}
}

func outputNode(writer *bufio.Writer, node node) {
	fmt.Fprintf(writer, "  <node id=\"%v\" label=\"%v\">\n", node.Uid, node.Name)
	fmt.Fprintf(writer, "	<attvalues>\n")
	fmt.Fprintf(writer, "	  <attvalue for=\"kind\" value=\"%v\"></attvalue>\n", node.Kind)
	fmt.Fprintf(writer, "	  <attvalue for=\"name\" value=\"%v\"></attvalue>\n", node.Name)
	fmt.Fprintf(writer, "	  <attvalue for=\"namespace\" value=\"%v\"></attvalue>\n", node.Namespace)
	for _, metric := range node.cpuMetrics {
		fmt.Fprintf(writer, "	  <attvalue for=\"cpumetric\" value=\"%v\" start=\"%v\" end=\"%v\"></attvalue>\n", metric.metric, formatDateTime(metric.start), formatDateTime(metric.end))
	}
	for _, metric := range node.memMetrics {
		fmt.Fprintf(writer, "	  <attvalue for=\"memmetric\" value=\"%v\" start=\"%v\" end=\"%v\"></attvalue>\n", metric.metric, formatDateTime(metric.start), formatDateTime(metric.end))
	}
	fmt.Fprintf(writer, "	</attvalues>\n")
	fmt.Fprintf(writer, "	<spells>\n")
	for _, interval := range node.intervals {
		fmt.Fprintf(writer, "	  <spell start=\"%v\" end=\"%v\"></spell>\n", formatDateTime(interval.start), formatDateTime(interval.end))
	}
	fmt.Fprintf(writer, "	</spells>\n")
	fmt.Fprintf(writer, "  </node>\n")
}

func outputEdge(writer *bufio.Writer, edge edge) {
	// TODO stop this, pending pods
	//if edge.SrcUid == "" || edge.TgtUid == "" {
	//	log.Fatalf("ERROR: edge with missing src/taget %v\n", edge)
	//	return
	//}

	fmt.Fprintf(writer, "  <edge source=\"%v\" target=\"%v\" kind=\"%v\">\n", edge.SrcUid, edge.TgtUid, edge.Kind)
	fmt.Fprintf(writer, "	<attvalues>\n")
	fmt.Fprintf(writer, "	  <attvalue for=\"srcname\" value=\"%v\"></attvalue>\n", edge.SrcName)
	fmt.Fprintf(writer, "	  <attvalue for=\"tgtname\" value=\"%v\"></attvalue>\n", edge.TgtName)
	fmt.Fprintf(writer, "	  <attvalue for=\"namespace\" value=\"%v\"></attvalue>\n", edge.Namespace)
	fmt.Fprintf(writer, "	</attvalues>\n")
	fmt.Fprintf(writer, "	<spells>\n")
	for _, interval := range edge.intervals {
		fmt.Fprintf(writer, "	  <spell start=\"%v\" end=\"%v\"></spell>\n", formatDateTime(interval.start), formatDateTime(interval.end))
	}
	fmt.Fprintf(writer, "	</spells>\n")
	fmt.Fprintf(writer, "  </edge>\n")
}

func formatDateTime(t time.Time) string {
	layout := "2006-01-02T15:04:05.999-07:00"
	return t.Format(layout)

}

func outputHeader(writer *bufio.Writer) {

	fmt.Fprintf(writer, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
	fmt.Fprintf(writer, "	<gexf xmlns=\"http://www.gexf.net/1.3\" version=\"1.3\" xmlns:viz=\"http://www.gexf.net/1.3/viz\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.gexf.net/1.3 http://www.gexf.net/1.3/gexf.xsd\">\n")
	fmt.Fprintf(writer, "	  <meta>\n")
	fmt.Fprintf(writer, "		<creator>Gephi 0.9</creator>\n")
	fmt.Fprintf(writer, "		<description></description>\n")
	fmt.Fprintf(writer, "	  </meta>\n")
	fmt.Fprintf(writer, "	  <graph defaultedgetype=\"directed\" timeformat=\"datetime\" timerepresentation=\"interval\" mode=\"dynamic\">\n")
	fmt.Fprintf(writer, "		<attributes class=\"node\" mode=\"static\">\n")
	fmt.Fprintf(writer, "		  <attribute id=\"kind\" title=\"kind\" type=\"string\"></attribute>\n")
	fmt.Fprintf(writer, "		  <attribute id=\"name\" title=\"name\" type=\"string\"></attribute>\n")
	fmt.Fprintf(writer, "		  <attribute id=\"namespace\" title=\"namespace\" type=\"string\"></attribute>\n")
	fmt.Fprintf(writer, "		</attributes>\n")
	fmt.Fprintf(writer, "		<attributes class=\"node\" mode=\"dynamic\">\n")
	fmt.Fprintf(writer, "		<attribute id=\"cpumetric\" title=\"cpumetric\" type=\"double\"></attribute>\n")
	fmt.Fprintf(writer, "		<attribute id=\"memmetric\" title=\"memmetric\" type=\"long\"></attribute>\n")
	fmt.Fprintf(writer, "		</attributes>\n")
	fmt.Fprintf(writer, "		<attributes class=\"edge\" mode=\"static\">\n")
	fmt.Fprintf(writer, "		  <attribute id=\"srcname\" title=\"srcname\" type=\"string\"></attribute>\n")
	fmt.Fprintf(writer, "		  <attribute id=\"tgtname\" title=\"tgtname\" type=\"string\"></attribute>\n")
	fmt.Fprintf(writer, "		  <attribute id=\"namespace\" title=\"namespace\" type=\"string\"></attribute>\n")
	fmt.Fprintf(writer, "		</attributes>\n")

}

func outputFooter(writer *bufio.Writer) {

	fmt.Fprintf(writer, "  </graph>\n")
	fmt.Fprintf(writer, "</gexf>\n")
}

func writeGEXF(filename string) {

	file, err := os.OpenFile(filename, os.O_RDWR|os.O_TRUNC|os.O_CREATE, 0644)
	if err != nil {
		panic(err.Error())
	}
	w := bufio.NewWriter(file)

	outputHeader(w)

	fmt.Fprintf(w, "    <nodes>\n")
	for _, node := range nodes {
		outputNode(w, node)
	}
	fmt.Fprintf(w, "    </nodes>\n")

	fmt.Fprintf(w, "    <edges>\n")
	for _, edge := range edges {
		outputEdge(w, edge)
	}
	fmt.Fprintf(w, "    </edges>\n")

	outputFooter(w)
	w.Flush()

	file.Close()
}
