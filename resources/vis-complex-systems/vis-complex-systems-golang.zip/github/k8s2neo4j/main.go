/*
  This code is part of the L&D work and tech talk "Beyond Dashboards - Visualising Complex Systems" by Andy Burgin - Sky Betting and Gaming
  https://sbg.technology/2020/04/28/vis-complex-systems/
*/
package main

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/neo4j/neo4j-go-driver/neo4j"
	appsv1 "k8s.io/api/apps/v1"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/clientcmd"
)

var (
	podCount int
)

func main() {

	// create neo4j session
	neo4jDriver, neo4jSession, connectErr := openNeo4jConnection("bolt://localhost:7687", "", "")
	if connectErr != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", connectErr)
		os.Exit(1)
	}

	kubeconfig := filepath.Join(
		os.Getenv("HOME"), ".kube", "config",
	)

	k8sClient, err := getK8sClient(kubeconfig)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		os.Exit(1)
	}

	// get nodes
	nodes, err := getNodes(k8sClient)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		os.Exit(2)
	}
	// loop nodes
	for _, node := range nodes.Items {
		fmt.Fprintf(os.Stdout, "Node : %v\n", node.Name)
		err = neo4jAddK8sObj(neo4jSession, &node, k8sClient)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(2)
		}
	}

	// get namespaces
	namespaces, err := getNamespaces(k8sClient)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		os.Exit(2)
	}
	// loop namespaces
	for _, namespace := range namespaces.Items {
		fmt.Fprintf(os.Stdout, "Namespace : %v\n", namespace.Name)
		err = neo4jAddK8sObj(neo4jSession, &namespace, k8sClient)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(2)
		}

		// get daemonsets
		daemonsets, err := getDaemonsetsForNamespace(namespace.Name, k8sClient)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(2)
		}
		// loop daemonset
		for _, daemonset := range daemonsets.Items {
			fmt.Fprintf(os.Stdout, " DaemonSet : %v %v\n", daemonset.Name, daemonset.UID)
			err = neo4jAddK8sObj(neo4jSession, &daemonset, k8sClient)
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: %v\n", err)
				os.Exit(2)
			}
			// link namespace to daemonset
			neo4jLink(neo4jSession, "Namespace", string(namespace.UID), "DaemonSet", string(daemonset.UID))
		}

		// get statefulsets
		statefulsets, err := getStatefulsetsForNamespace(namespace.Name, k8sClient)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(2)
		}
		// loop statefulset
		for _, statefulset := range statefulsets.Items {
			fmt.Fprintf(os.Stdout, " StatefulSet : %v %v\n", statefulset.Name, statefulset.UID)
			err = neo4jAddK8sObj(neo4jSession, &statefulset, k8sClient)
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: %v\n", err)
				os.Exit(2)
			}
			// link namespace to statefulset
			neo4jLink(neo4jSession, "Namespace", string(namespace.UID), "StatefulSet", string(statefulset.UID))
		}

		// get deployments
		deployments, err := getDeploymentsForNamespace(namespace.Name, k8sClient)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(2)
		}
		// loop deployment
		for _, deployment := range deployments.Items {
			fmt.Fprintf(os.Stdout, " Deployment : %v %v\n", deployment.Name, deployment.UID)
			err = neo4jAddK8sObj(neo4jSession, &deployment, k8sClient)
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: %v\n", err)
				os.Exit(2)
			}
			// link namespace to deployment
			neo4jLink(neo4jSession, "Namespace", string(namespace.UID), "Deployment", string(deployment.UID))
		}

		// get replicasets
		replicasets, err := getReplicasetsForNamespace(namespace.Name, k8sClient)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(2)
		}
		// loop replicasets
		for _, replicaset := range replicasets.Items {
			fmt.Fprintf(os.Stdout, "   ReplicaSet : %v %v\n", replicaset.Name, replicaset.UID)
			err = neo4jAddK8sObj(neo4jSession, &replicaset, k8sClient)
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: %v\n", err)
				os.Exit(2)
			}

			if controllerRef := metav1.GetControllerOf(&replicaset); controllerRef != nil {
				fmt.Fprintf(os.Stdout, "    replicaset: %v %v %v\n", replicaset.Name, controllerRef.UID, controllerRef.Kind)
				// neo4j link replicaset to deployment
				neo4jLink(neo4jSession, string(controllerRef.Kind), string(controllerRef.UID), "ReplicaSet", string(replicaset.UID))
			} else {
				fmt.Fprintf(os.Stdout, "    replicaset: %v\n", replicaset.Name)
				// neo4j link replicaset to namespace
				neo4jLink(neo4jSession, "Namespace", string(namespace.UID), "ReplicaSet", string(replicaset.UID))
			}
			// // neo4j link replicaset to namespace
			// neo4jLink(neo4jSession, "Namespace", string(namespace.UID), "ReplicaSet", string(replicaset.UID))
		}

		// get jobs
		jobs, err := getJobsForNamespace(namespace.Name, k8sClient)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(2)
		}
		// loop jobs
		for _, job := range jobs.Items {
			fmt.Fprintf(os.Stdout, " Job : %v %v\n", job.Name, job.UID)
			err = neo4jAddK8sObj(neo4jSession, &job, k8sClient)
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: %v\n", err)
				os.Exit(2)
			}
			// neo4j link job to namespace
			neo4jLink(neo4jSession, "Namespace", string(namespace.UID), "Job", string(job.UID))
		}

		// get pods
		pods, err := getPodsForNamespace(namespace.Name, k8sClient)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(2)
		}
		// loop pod
		for _, pod := range pods.Items {
			fmt.Fprintf(os.Stdout, "     Pod : %v %v\n", pod.Name, pod.UID)
			err = neo4jAddK8sObj(neo4jSession, &pod, k8sClient)
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: %v\n", err)
				os.Exit(2)
			}
			podCount++
			if controllerRef := metav1.GetControllerOf(&pod); controllerRef != nil {
				fmt.Fprintf(os.Stdout, "    xxxx pod: %v %v %v\n", pod.Name, controllerRef.UID, controllerRef.Kind)
				// neo4j add link pod to parent
				neo4jLink(neo4jSession, string(controllerRef.Kind), string(controllerRef.UID), "Pod", string(pod.UID))
			} else {
				fmt.Fprintf(os.Stdout, "    pod: %v linked to namespace %v\n", pod.Name, namespace.Name)
				// neo4j link pod to namespace
				neo4jLink(neo4jSession, "Namespace", string(namespace.UID), "Pod", string(pod.UID))
			}
			//link node to pod
			for _, node := range nodes.Items {
				for i := range node.Status.Addresses {
					ipaddr := node.Status.Addresses[i]
					if pod.Status.HostIP == ipaddr.Address {
						fmt.Fprintf(os.Stdout, "    node: %v linked to pod %v\n", node.Name, pod.Name)
						// neo4j link node to pod
						neo4jLink(neo4jSession, "Node", string(node.UID), "Pod", string(pod.UID))
					}
				}
			}

			// //link namespace to pod
			// neo4jLink(neo4jSession, "Namespace", string(namespace.UID), "Pod", string(pod.UID))
		}

		// get services
		services, err := getServicesForNamespace(namespace.Name, k8sClient)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(2)
		}
		// loop services
		for _, service := range services.Items {
			fmt.Fprintf(os.Stdout, " service : %v %v\n", service.Name, service.UID)
			// neo4j add service
			err = neo4jAddK8sObj(neo4jSession, &service, k8sClient)
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: %v\n", err)
				os.Exit(2)
			}
			// neo4j link service to namespace
			neo4jLink(neo4jSession, "Namespace", string(namespace.UID), "Service", string(service.UID))

			// get pods in namespace ans see if they belong to the current service
			pods, err := getPodsForService(&service, namespace.Name, k8sClient)
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: %v\n", err)
				os.Exit(2)
			}
			// loop pod
			for _, pod := range pods.Items {
				fmt.Fprintf(os.Stdout, "  link service %v to pod %v\n", service.Name, pod.Name)
				// neo4j link service to pod
				neo4jLink(neo4jSession, "Service", string(service.UID), "Pod", string(pod.UID))
			}
		}
	}

	// close neo4j session
	closeErr := closeNeo4jConnection(neo4jDriver, neo4jSession)
	if closeErr != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", closeErr)
		os.Exit(1)
	}

	fmt.Fprintf(os.Stdout, "Exported %v Pods\n", podCount)
}

/**
  N E O 4 J   F U N C T I O N S
*/

func openNeo4jConnection(uri, username, password string) (neo4j.Driver, neo4j.Session, error) {
	driver, err := neo4j.NewDriver(uri, neo4j.BasicAuth(username, password, ""))
	if err != nil {
		return nil, nil, err
	}

	sess, err := driver.Session(neo4j.AccessModeWrite)
	if err != nil {
		return driver, nil, err
	}

	return driver, sess, err
}

func closeNeo4jConnection(driver neo4j.Driver, sess neo4j.Session) error {
	sessionCloseError := sess.Close()
	if sessionCloseError != nil {
		return sessionCloseError
	}
	driverCloseError := driver.Close()
	if driverCloseError != nil {
		return driverCloseError
	}

	return nil
}
func neo4jAddK8sObj(sess neo4j.Session, obj metav1.Object, k8sClient kubernetes.Interface) error {

	kind, vals := extractK8sObjectFields(obj, k8sClient)

	cypher := "CREATE (n:" + kind + " { "
	for fieldName := range vals {
		if cypher[len(cypher)-1:] != " " {
			cypher += ", "
		}
		fieldName = strings.ToLower(fieldName)
		cypher += fieldName + " :$" + fieldName

	}
	cypher += "})"
	//fmt.Fprintf(os.Stdout, "cypher: %v %v\n", cypher, vals)

	return runNeo4jCypher(sess, cypher, vals)
}

func neo4jLink(sess neo4j.Session, srcKind string, srcId string, tgtKind string, tgtId string) error {

	vals := make(map[string]interface{})
	vals["srcid"] = srcId
	vals["tgtid"] = tgtId

	cypher := "MATCH (s:" + srcKind + " {uid:$srcid}),(t:" + tgtKind + " {uid:$tgtid})\nMERGE (s)-[o:OWNS]->(t)"
	//fmt.Fprintf(os.Stdout, "cypher: %v %v\n", cypher, vals)

	return runNeo4jCypher(sess, cypher, vals)
}

func runNeo4jCypher(sess neo4j.Session, cypher string, vals map[string]interface{}) error {

	_, err := sess.WriteTransaction(func(transaction neo4j.Transaction) (interface{}, error) {
		result, err := transaction.Run(cypher, vals)
		if err != nil {
			return nil, err
		}
		if result.Next() {
			return result.Record().GetByIndex(0), nil
		}
		return nil, result.Err()
	})

	return err
}

/**
  K 8 S   F U N C T I O N S
*/

func extractK8sObjectFields(obj metav1.Object, k8sClient kubernetes.Interface) (string, map[string]interface{}) {
	// Create map
	results := make(map[string]interface{})
	kind := ""
	// Get default fields
	results["uid"] = obj.GetUID()
	results["name"] = obj.GetName()
	results["created"] = obj.GetCreationTimestamp().String()
	results["age"] = time.Now().Unix() - obj.GetCreationTimestamp().Unix()

	// Switch on object type
	switch o := obj.(type) {
	case *corev1.Node:
		kind = "Node"
		for address := range o.Status.Addresses {
			results[strings.ToLower(string(o.Status.Addresses[address].Type))] = o.Status.Addresses[address].Address
		}
		results["nodealloccpu"] = o.Status.Allocatable.Cpu().MilliValue()
		results["nodeallocmem"], _ = o.Status.Allocatable.Memory().AsInt64()
		results["nodecapcpu"] = o.Status.Capacity.Cpu().MilliValue()
		results["nodecapmem"], _ = o.Status.Capacity.Memory().AsInt64()
	case *corev1.Namespace:
		kind = "Namespace"
		results["namespace"] = o.Namespace
		lrs, err := getLimitRangeForNamespace(o.Name, k8sClient)
		if err != nil {
			log.Fatal(err)
		}

		// get limitrange
		lrcount := 0
		for _, lr := range lrs.Items {
			for _, r := range lr.Spec.Limits {
				if lrcount > 0 {
					fmt.Fprintf(os.Stdout, "WARNING: multiple resource limits specified for namespace %v\n", o.Namespace)
				}
				if r.Type == "Container" {
					defCpu := r.Default.Cpu().MilliValue()
					defMem, _ := r.Default.Memory().AsInt64()
					defReqCpu := r.DefaultRequest.Cpu().MilliValue()
					defReqMem, _ := r.DefaultRequest.Memory().AsInt64()
					fmt.Fprintf(os.Stdout, "      def cpu: %v\n", defCpu)
					fmt.Fprintf(os.Stdout, "      def cpu: %v\n", defMem)
					fmt.Fprintf(os.Stdout, "      defreq cpu: %v\n", defReqCpu)
					fmt.Fprintf(os.Stdout, "      defreq mem: %v\n", defReqMem)
					results["defcpu"] = defCpu
					results["defmem"] = getBytesToKiloBytes(defMem)
					results["defreqcpu"] = defReqCpu
					results["defreqmem"] = getBytesToKiloBytes(defReqMem)
					lrcount++
				}
			}
		}
		results["limitcount"] = lrcount
	case *appsv1.DaemonSet:
		kind = "DaemonSet"
		results["namespace"] = o.Namespace
	case *appsv1.StatefulSet:
		kind = "StatefulSet"
		results["namespace"] = o.Namespace
	case *appsv1.Deployment:
		kind = "Deployment"
		results["namespace"] = o.Namespace
	case *appsv1.ReplicaSet:
		kind = "ReplicaSet"
		results["namespace"] = o.Namespace
	case *batchv1.Job:
		kind = "Job"
		results["namespace"] = o.Namespace
		results["completions"] = o.Spec.Completions
		results["parallelism"] = o.Spec.Parallelism
	case *corev1.Pod:
		kind = "Pod"
		results["namespace"] = o.Namespace
		results["node"] = o.Spec.NodeName
		results["hostip"] = o.Status.HostIP
		results["podip"] = o.Status.PodIP
		results["status"] = o.Status.Phase
		var restartCount int32
		for _, container := range o.Status.ContainerStatuses {
			restartCount = restartCount + container.RestartCount
		}
		results["restartcount"] = restartCount
		var cpuRequestTotal int64
		var memRequestTotal int64
		cpuRequestTotal, memRequestTotal = getPodResourceTotal(*o, "requests")
		fmt.Fprintf(os.Stdout, "      pod: id %v resource cpu request total %v\n", o.Name, cpuRequestTotal)
		fmt.Fprintf(os.Stdout, "      pod: id %v resource mem request total %v\n", o.Name, memRequestTotal)
		results["cpurequesttotal"] = cpuRequestTotal
		results["memrequesttotal"] = getBytesToKiloBytes(memRequestTotal)
		var cpuLimitsTotal int64
		var memLimitsTotal int64
		cpuLimitsTotal, memLimitsTotal = getPodResourceTotal(*o, "limits")
		fmt.Fprintf(os.Stdout, "      pod: id %v resource cpu limits total %v\n", o.Name, cpuLimitsTotal)
		fmt.Fprintf(os.Stdout, "      pod: id %v resource mem limits total %v\n", o.Name, memLimitsTotal)
		results["cpulimitstotal"] = cpuLimitsTotal
		results["memlimitstotal"] = getBytesToKiloBytes(memLimitsTotal)
	case *corev1.Service:
		kind = "Service"
		results["namespace"] = o.Namespace
		results["type"] = o.Spec.Type
	}

	// Return map
	return kind, results
}

func getK8sClient(configLocation string) (kubernetes.Interface, error) {
	kubeconfig := filepath.Clean(configLocation)
	config, err := clientcmd.BuildConfigFromFlags("", kubeconfig)
	if err != nil {
		log.Fatal(err)
	}
	kubeclientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return nil, err
	}
	return kubeclientset, nil
}

func getNodes(k8sClient kubernetes.Interface) (*corev1.NodeList, error) {
	nodes, err := k8sClient.CoreV1().Nodes().List(metav1.ListOptions{})
	return nodes, err
}

func getNamespaces(k8sClient kubernetes.Interface) (*corev1.NamespaceList, error) {
	namespaces, err := k8sClient.CoreV1().Namespaces().List(metav1.ListOptions{})
	return namespaces, err
}

func getDaemonsetsForNamespace(namespace string, k8sClient kubernetes.Interface) (*appsv1.DaemonSetList, error) {
	daemonsets, err := k8sClient.AppsV1().DaemonSets(namespace).List(metav1.ListOptions{})
	return daemonsets, err
}

func getJobsForNamespace(namespace string, k8sClient kubernetes.Interface) (*batchv1.JobList, error) {
	jobs, err := k8sClient.BatchV1().Jobs(namespace).List(metav1.ListOptions{})
	return jobs, err
}

func getStatefulsetsForNamespace(namespace string, k8sClient kubernetes.Interface) (*appsv1.StatefulSetList, error) {
	statefulsets, err := k8sClient.AppsV1().StatefulSets(namespace).List(metav1.ListOptions{})
	return statefulsets, err
}

func getDeploymentsForNamespace(namespace string, k8sClient kubernetes.Interface) (*appsv1.DeploymentList, error) {
	deployments, err := k8sClient.AppsV1().Deployments(namespace).List(metav1.ListOptions{})
	return deployments, err
}

func getReplicasetsForNamespace(namespace string, k8sClient kubernetes.Interface) (*appsv1.ReplicaSetList, error) {
	replicasets, err := k8sClient.AppsV1().ReplicaSets(namespace).List(metav1.ListOptions{})
	return replicasets, err
}

func getServicesForNamespace(namespace string, k8sClient kubernetes.Interface) (*corev1.ServiceList, error) {
	services, err := k8sClient.CoreV1().Services(namespace).List(metav1.ListOptions{})
	return services, err
}

func getPodsForNamespace(namespace string, k8sClient kubernetes.Interface) (*corev1.PodList, error) {
	pods, err := k8sClient.CoreV1().Pods(namespace).List(metav1.ListOptions{})
	return pods, err
}

func getLimitRangeForNamespace(namespace string, k8sClient kubernetes.Interface) (*corev1.LimitRangeList, error) {
	limRng, err := k8sClient.CoreV1().LimitRanges(namespace).List(metav1.ListOptions{})
	return limRng, err
}

func getPodsForService(svc *corev1.Service, namespace string, k8sClient kubernetes.Interface) (*corev1.PodList, error) {
	if len(svc.Spec.Selector) > 0 {
		set := labels.Set(svc.Spec.Selector)
		listOptions := metav1.ListOptions{LabelSelector: set.AsSelector().String()}
		pods, err := k8sClient.CoreV1().Pods(namespace).List(listOptions)
		return pods, err
	} else {
		fmt.Fprintf(os.Stdout, "  no selector - skipping\n")
		return &corev1.PodList{}, nil
	}
}

func getPodResourceTotal(pod corev1.Pod, resType string) (int64, int64) {
	var cpuRequestTotal int64
	var memRequestTotal int64

	for _, container := range pod.Spec.Containers {

		var memRequest int64
		var cpuRequest int64
		var ok bool
		if resType == "requests" {
			fmt.Fprintf(os.Stdout, "      container: id %v resource cpu request %v\n", container.Name, container.Resources.Requests.Cpu().MilliValue())
			fmt.Fprintf(os.Stdout, "      container: id %v resource mem request %v\n", container.Name, container.Resources.Requests.Memory().AsDec())
			cpuRequest = container.Resources.Requests.Cpu().MilliValue()
			memRequest, ok = container.Resources.Requests.Memory().AsInt64()
		} else {
			fmt.Fprintf(os.Stdout, "      container: id %v resource cpu limit %v\n", container.Name, container.Resources.Limits.Cpu().MilliValue())
			fmt.Fprintf(os.Stdout, "      container: id %v resource mem limit %v\n", container.Name, container.Resources.Limits.Memory().AsDec())
			cpuRequest = container.Resources.Limits.Cpu().MilliValue()
			memRequest, ok = container.Resources.Limits.Memory().AsInt64()
		}
		if !ok {

			//if it ends in "m" the recalculate
			var memval string = container.Resources.Requests.Memory().String()
			if strings.HasSuffix(memval, "m") {
				//fmt.Fprintf(os.Stdout, "   found %v\n", container.Resources.Requests.Memory().AsDec())
				memRequest = container.Resources.Requests.Memory().ScaledValue(-9)
			}
			fmt.Fprintf(os.Stdout, "WARNING: memory limit stored as cpu tick, fix applied\n")
		}
		cpuRequestTotal += cpuRequest
		memRequestTotal += memRequest
	}
	return cpuRequestTotal, memRequestTotal
}

func getBytesToKiloBytes(bytes int64) int64 {

	return int64(bytes / 1024)
}
