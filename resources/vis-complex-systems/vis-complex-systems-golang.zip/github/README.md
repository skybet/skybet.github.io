# Kubernetes Graph Visualisation Tools

3 tools for working with k8s and graph databases and visualisation tools.

## k8s2neo4j
- Sends k8s objects with attributes and relationship heirachy to neo4j.
- Connects to current kubernetes context as defined in ~/.kube/config  
- Connects to neo4j via bolt://localhost:7687
- Depends on https://github.com/neo4j/neo4j-go-driver 

## k8srecorder
- Connects to current kubernetes context as defined in ~/.kube/config  
- Generates log of object creation and relationships with associated properties (for use with k8srecord2gexf).
- Additionally records pod stats from metrics server.

## k8srecord2gexf
- Reads output from k8srecorder and generates a gexf file for import into gephi.
- Generates a gexf file for import into gephi, suitable for timeline analysis.

This code is part of the L&D work and tech talk "Beyond Dashboards - Visualising Complex Systems" by Andy Burgin - Sky Betting and Gaming https://sbg.technology/2020/04/28/vis-complex-systems/