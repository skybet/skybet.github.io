/*
  This code is part of the L&D work and tech talk "Beyond Dashboards - Visualising Complex Systems" by Andy Burgin - Sky Betting and Gaming
  https://sbg.technology/2020/04/28/vis-complex-systems/
*/
package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/robfig/cron/v3"
	"gopkg.in/inf.v0"
	appsv1 "k8s.io/api/apps/v1"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/informers"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/cache"
	"k8s.io/client-go/tools/clientcmd"
	metricsclient "k8s.io/metrics/pkg/client/clientset/versioned"
)

type serviceResource struct {
	Uid       string
	Name      string
	Namespace string
	deleted   bool
}

type namespaceResource struct {
	Uid     string
	Name    string
	deleted bool
}

type nodeResource struct {
	Uid     string
	Name    string
	Hostip  string
	deleted bool
}

type daemonSetResource struct {
	Uid       string
	Name      string
	Namespace string
}

type statefulSetResource struct {
	Uid       string
	Name      string
	Namespace string
}

type deploymentResource struct {
	Uid       string
	Name      string
	Namespace string
}

type replicaSetResource struct {
	Uid       string
	Name      string
	Namespace string
}

type jobResource struct {
	Uid       string
	Name      string
	Namespace string
}

type podResource struct {
	Uid       string
	Name      string
	Namespace string
	deleted   bool
}

type endpointResource struct {
	Uid       string
	Name      string
	Namespace string
}

type deleteEvent struct {
	Uid       string
	Name      string
	Namespace string
}

type relationshipEvent struct {
	SrcUid    string
	TgtUid    string
	SrcName   string
	TgtName   string
	Namespace string
	Kind      string
}

var (
	mutex                         sync.Mutex
	serviceResources              []serviceResource
	relationshipsMissingService   []relationshipEvent
	namespaceResources            []namespaceResource
	relationshipsMissingNamespace []relationshipEvent
	nodeResources                 []nodeResource
	podResources                  []podResource
	metricsclientset              metricsclient.Interface
)

func main() {

	kubeconfig := filepath.Join(
		os.Getenv("HOME"), ".kube", "config",
	)
	kubeconfig = filepath.Clean(kubeconfig)

	var clientset kubernetes.Interface
	var err error
	clientset, metricsclientset, err = getK8sClient(kubeconfig)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		os.Exit(1)
	}

	informerFactory := informers.NewSharedInformerFactory(clientset, time.Second*30)

	informerFactory.Core().V1().Nodes().Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc:    addObject,
		DeleteFunc: deleteObject,
	})

	informerFactory.Core().V1().Namespaces().Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc:    addObject,
		DeleteFunc: deleteObject,
	})

	informerFactory.Apps().V1().DaemonSets().Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc:    addObject,
		DeleteFunc: deleteObject,
	})

	informerFactory.Apps().V1().StatefulSets().Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc:    addObject,
		DeleteFunc: deleteObject,
	})

	informerFactory.Batch().V1().Jobs().Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc:    addObject,
		DeleteFunc: deleteObject,
	})

	informerFactory.Apps().V1().Deployments().Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc:    addObject,
		DeleteFunc: deleteObject,
	})

	informerFactory.Apps().V1().ReplicaSets().Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc:    addObject,
		DeleteFunc: deleteObject,
	})

	informerFactory.Core().V1().Pods().Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc:    addObject,
		UpdateFunc: updateObject,
		DeleteFunc: deleteObject,
	})

	informerFactory.Core().V1().Services().Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc:    addObject,
		DeleteFunc: deleteObject,
	})

	informerFactory.Core().V1().Endpoints().Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc:    addObject,
		UpdateFunc: updateObject,
		DeleteFunc: deleteObject,
	})

	c := cron.New()
	c.AddFunc("@every 1m", extractMetrics)
	c.Start()

	informerFactory.Start(wait.NeverStop)
	<-wait.NeverStop
}

func extractMetrics() {
	podMetrics, err := metricsclientset.MetricsV1beta1().PodMetricses("").List(v1.ListOptions{})
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	for _, podMetric := range podMetrics.Items {
		podContainers := podMetric.Containers
		cpuUsageTotal := new(inf.Dec)
		var memUsageTotal int64
		for _, container := range podContainers {
			cpuQuantity := container.Usage.Cpu().AsDec()
			cpuUsageTotal = cpuUsageTotal.Add(cpuUsageTotal, cpuQuantity)
			memQuantity, ok := container.Usage.Memory().AsInt64()
			if !ok {
				break
			}
			memUsageTotal = memUsageTotal + memQuantity
		}
		pod := lookupPod(podMetric.Name, podMetric.Namespace, false)
		if pod.Name == "" {
			//fmt.Printf("pod %v not found\n", podMetric.Name)
		} else {
			jsonData := fmt.Sprintf("{\"Uid\":\"%v\",\"Name\":\"%v\",\"Namespace\":\"%v\",\"CpuUsage\":\"%v\",\"MemUsage\":\"%v\"}", pod.Uid, pod.Name, pod.Namespace, cpuUsageTotal, memUsageTotal)
			outputEvent("UPDATE", "Pod", jsonData)
		}
	}
}

func addObject(iObj interface{}) {
	obj := iObj.(v1.Object)
	var kind string
	var jsonData []byte
	var err error

	switch obj.(type) {
	case *corev1.Node:
		kind = "Node"
		nodeObj := iObj.(*corev1.Node)
		var hostname string
		var hostip string
		for _, address := range nodeObj.Status.Addresses {
			if address.Type == "Hostname" {
				hostname = address.Address
			}
			if address.Type == "ExternalIP" || address.Type == "InternalIP" {
				hostip = address.Address
			}
		}
		node := nodeResource{
			Uid:     string(nodeObj.ObjectMeta.GetUID()),
			Name:    hostname,
			Hostip:  hostip,
			deleted: false,
		}
		nodeResources = append(nodeResources, node)
		jsonData, err = json.Marshal(node)
		if err != nil {
			log.Println(err)
		}
	case *corev1.Namespace:
		kind = "Namespace"
		nsObj := iObj.(*corev1.Namespace)
		nsr := namespaceResource{
			Uid:     string(nsObj.ObjectMeta.GetUID()),
			Name:    nsObj.ObjectMeta.Name,
			deleted: false,
		}
		namespaceResources = append(namespaceResources, nsr)
		jsonData, err = json.Marshal(nsr)
		if err != nil {
			log.Println(err)
		}
	case *appsv1.DaemonSet:
		kind = "DaemonSet"
		dsObj := iObj.(*appsv1.DaemonSet)
		dsr := daemonSetResource{
			Uid:       string(dsObj.ObjectMeta.GetUID()),
			Name:      dsObj.ObjectMeta.Name,
			Namespace: dsObj.GetNamespace(),
		}
		jsonData, err = json.Marshal(dsr)
		if err != nil {
			log.Println(err)
		}
	case *appsv1.StatefulSet:
		kind = "StatefulSet"
		ssObj := iObj.(*appsv1.StatefulSet)
		ssr := statefulSetResource{
			Uid:       string(ssObj.ObjectMeta.GetUID()),
			Name:      ssObj.ObjectMeta.Name,
			Namespace: ssObj.GetNamespace(),
		}
		jsonData, err = json.Marshal(ssr)
		if err != nil {
			log.Println(err)
		}
	case *appsv1.Deployment:
		kind = "Deployment"
		dObj := iObj.(*appsv1.Deployment)
		dr := deploymentResource{
			Uid:       string(dObj.ObjectMeta.GetUID()),
			Name:      dObj.ObjectMeta.Name,
			Namespace: dObj.GetNamespace(),
		}
		jsonData, err = json.Marshal(dr)
		if err != nil {
			log.Println(err)
		}
	case *appsv1.ReplicaSet:
		kind = "ReplicaSet"
		rsObj := iObj.(*appsv1.ReplicaSet)
		rsr := replicaSetResource{
			Uid:       string(rsObj.ObjectMeta.GetUID()),
			Name:      rsObj.ObjectMeta.Name,
			Namespace: rsObj.GetNamespace(),
		}
		jsonData, err = json.Marshal(rsr)
		if err != nil {
			log.Println(err)
		}
		if rsObj.OwnerReferences != nil {
			if rsObj.OwnerReferences[0].Kind == "Deployment" {
				addRelationship("DeploymentToReplicaset", string(rsObj.ObjectMeta.OwnerReferences[0].UID), string(rsObj.ObjectMeta.GetUID()), rsObj.ObjectMeta.OwnerReferences[0].Name, rsObj.ObjectMeta.GetName(), rsObj.ObjectMeta.GetNamespace(), getGephiTime(time.Now()))
			}
		}
	case *batchv1.Job:
		kind = "Job"
		jObj := iObj.(*batchv1.Job)
		jr := jobResource{
			Uid:       string(jObj.ObjectMeta.GetUID()),
			Name:      jObj.ObjectMeta.Name,
			Namespace: jObj.GetNamespace(),
		}
		jsonData, err = json.Marshal(jr)
		if err != nil {
			log.Println(err)
		}
	case *corev1.Pod:
		kind = "Pod"
		podObj := iObj.(*corev1.Pod)
		pr := podResource{
			Uid:       string(podObj.ObjectMeta.GetUID()),
			Name:      podObj.ObjectMeta.Name,
			Namespace: podObj.GetNamespace(),
		}
		jsonData, err = json.Marshal(pr)
		if err != nil {
			log.Println(err)
		}
		podResources = append(podResources, pr)
		if podObj.OwnerReferences != nil {
			if podObj.OwnerReferences[0].Kind == "ReplicaSet" {
				addRelationship("ReplicasetToPod", string(podObj.ObjectMeta.OwnerReferences[0].UID), string(podObj.ObjectMeta.GetUID()), podObj.ObjectMeta.OwnerReferences[0].Name, podObj.ObjectMeta.GetName(), podObj.ObjectMeta.GetNamespace(), getGephiTime(time.Now()))
			}
			if podObj.OwnerReferences[0].Kind == "DaemonSet" {
				addRelationship("DaemonsetToPod", string(podObj.ObjectMeta.OwnerReferences[0].UID), string(podObj.ObjectMeta.GetUID()), podObj.ObjectMeta.OwnerReferences[0].Name, podObj.ObjectMeta.GetName(), podObj.ObjectMeta.GetNamespace(), getGephiTime(time.Now()))
			}
			if podObj.OwnerReferences[0].Kind == "StatefulSet" {
				addRelationship("StatefulSetToPod", string(podObj.ObjectMeta.OwnerReferences[0].UID), string(podObj.ObjectMeta.GetUID()), podObj.ObjectMeta.OwnerReferences[0].Name, podObj.ObjectMeta.GetName(), podObj.ObjectMeta.GetNamespace(), getGephiTime(time.Now()))
			}
			if podObj.OwnerReferences[0].Kind == "Job" {
				addRelationship("JobToPod", string(podObj.ObjectMeta.OwnerReferences[0].UID), string(podObj.ObjectMeta.GetUID()), podObj.ObjectMeta.OwnerReferences[0].Name, podObj.ObjectMeta.GetName(), podObj.ObjectMeta.GetNamespace(), getGephiTime(time.Now()))
			}
			nodeName, nodeId := lookupNode(podObj.Status.HostIP, false)
			if nodeId == "" {
				//log.Printf("node not found - %v", podObj.Name)
			} else {
				addRelationship("PodToNode", string(podObj.ObjectMeta.GetUID()), nodeId, podObj.ObjectMeta.GetName(), nodeName, podObj.ObjectMeta.GetNamespace(), getGephiTime(time.Now()))
			}
		}
	case *corev1.Service:
		kind = "Service"
		serviceObj := iObj.(*corev1.Service)
		sr := serviceResource{
			Uid:       string(serviceObj.ObjectMeta.GetUID()),
			Name:      serviceObj.ObjectMeta.Name,
			Namespace: serviceObj.GetNamespace(),
			deleted:   false,
		}
		jsonData, err = json.Marshal(sr)
		if err != nil {
			log.Println(err)
		}
		serviceResources = append(serviceResources, sr)
	case *corev1.Endpoints:
		kind = "Endpoints"
		endpointObj := iObj.(*corev1.Endpoints)
		serviceName := endpointObj.ObjectMeta.Name
		serviceNameSpace := endpointObj.ObjectMeta.Namespace
		er := endpointResource{
			Uid:       string(endpointObj.ObjectMeta.GetUID()),
			Name:      endpointObj.ObjectMeta.Name,
			Namespace: endpointObj.GetNamespace(),
		}
		jsonData, err = json.Marshal(er)
		if err != nil {
			log.Println(err)
		}

		for _, subset := range endpointObj.Subsets {
			for _, address := range subset.Addresses {
				if address.TargetRef == nil {
					return
				}
				endPointKind := address.TargetRef.Kind
				//log.Printf("===add endpoint %s %s to service %s in %s", address.TargetRef.Name, address.TargetRef.UID, serviceName, serviceNameSpace)
				addRelationship("ServiceTo"+endPointKind, "", string(address.TargetRef.UID), serviceName, address.TargetRef.Name, serviceNameSpace, getGephiTime(time.Now()))
			}
		}
	}

	//output object
	if kind != "Endpoints" {
		outputEvent("ADD", kind, string(jsonData))

		// add namespace relationship
		if kind != "Namespace" && kind != "Node" {
			addRelationship("NamespaceTo"+kind, getNamespaceResouceUid(obj.GetNamespace(), false), string(obj.GetUID()), obj.GetNamespace(), obj.GetName(), obj.GetNamespace(), getGephiTime(time.Now()))
		}

		// output any missing serviceTo relationships
		if kind == "Service" {
			addRelationshipsWithMissingService()
		}

		if kind == "Namespace" {
			addRelationshipsWithMissingNamespace()
		}
	}

}

func deleteObject(iObj interface{}) {
	obj := iObj.(v1.Object)
	var kind string
	// Switch on object type
	switch obj.(type) {
	case *corev1.Node:
		kind = "Node"
		nodeObj := iObj.(*corev1.Node)

		// remove node from
		for _, node := range nodeResources {
			if node.Uid == string(nodeObj.ObjectMeta.GetUID()) {
				node.deleted = true
			}
		}
	case *corev1.Namespace:
		kind = "Namespace"
		nsObj := iObj.(*corev1.Namespace)
		for _, namespace := range namespaceResources {
			if namespace.Uid == string(nsObj.ObjectMeta.GetUID()) {
				namespace.deleted = true
			}
		}
	case *appsv1.DaemonSet:
		kind = "DaemonSet"
	case *appsv1.StatefulSet:
		kind = "StatefulSet"
	case *appsv1.Deployment:
		kind = "Deployment"
	case *appsv1.ReplicaSet:
		kind = "ReplicaSet"
	case *batchv1.Job:
		kind = "Job"
	case *corev1.Pod:
		kind = "Pod"
		podObj := iObj.(*corev1.Pod)
		nodeName, nodeId := lookupNode(podObj.Status.HostIP, true)
		removeRelationship("PodToNode", string(podObj.ObjectMeta.GetUID()), nodeId, podObj.ObjectMeta.GetName(), nodeName, podObj.ObjectMeta.GetNamespace(), getGephiTime(time.Now()))
		for i, pod := range podResources {
			if pod.Uid == string(podObj.ObjectMeta.GetUID()) {
				podResources[i].deleted = true
			}
		}
	case *corev1.Service:
		kind = "Service"
		serviceObj := iObj.(*corev1.Service)
		for i, resource := range serviceResources {
			if resource.Uid == string(serviceObj.ObjectMeta.GetUID()) {
				serviceResources[i].deleted = true
			}
		}
	case *corev1.Endpoints:
		kind = "Endpoints"
		endpointObj := iObj.(*corev1.Endpoints)
		serviceName := endpointObj.ObjectMeta.Name
		serviceNameSpace := endpointObj.ObjectMeta.Namespace
		for _, subset := range endpointObj.Subsets {
			for _, address := range subset.Addresses {
				endPointKind := address.TargetRef.Kind
				//log.Printf("===delete endpoint %s %s from service %s in %s", address.TargetRef.Name, address.TargetRef.UID, serviceName, serviceNameSpace)
				removeRelationship("ServiceTo"+endPointKind, "", string(address.TargetRef.UID), serviceName, address.TargetRef.Name, serviceNameSpace, getGephiTime(time.Now()))
			}
		}
	}

	if kind != "Endpoints" {
		de := deleteEvent{
			Uid:       string(obj.GetUID()),
			Name:      obj.GetName(),
			Namespace: obj.GetNamespace(),
		}
		jsonData, err := json.Marshal(de)
		if err != nil {
			log.Println(err)
		}
		outputEvent("DELETE", kind, string(jsonData))
		if kind != "Namespace" && kind != "Node" {
			removeRelationship("NamespaceTo"+kind, getNamespaceResouceUid(obj.GetNamespace(), true), string(obj.GetUID()), obj.GetNamespace(), obj.GetName(), obj.GetNamespace(), getGephiTime(time.Now()))
		}
	}

	log.Printf("> deleteObject(): %v %v", kind, obj.GetName())
}

func updateObject(iOldObj interface{}, iNewObj interface{}) {
	newObj := iNewObj.(v1.Object)

	// Switch on object type
	switch newObj.(type) {
	case *corev1.Endpoints:
		newEndpointObj := iNewObj.(*corev1.Endpoints)
		oldEndpointObj := iOldObj.(*corev1.Endpoints)
		if newEndpointObj.ResourceVersion == oldEndpointObj.ResourceVersion {
			return
		}

		serviceName := newEndpointObj.ObjectMeta.Name
		serviceNameSpace := newEndpointObj.ObjectMeta.Namespace

		//ignore the kube scheduler it phantom updates every 2 secs
		if serviceName == "kube-scheduler" || serviceName == "kube-controller-manager" {
			return
		}

		//find removed address
		for _, oldSubset := range oldEndpointObj.Subsets {
			for _, oldAddress := range oldSubset.Addresses {
				found := false
				for _, newSubset := range newEndpointObj.Subsets {
					for _, newAddress := range newSubset.Addresses {
						if newAddress.TargetRef.Name == oldAddress.TargetRef.Name {
							found = true
						}
					}
				}
				if !found {
					endPointKind := oldAddress.TargetRef.Kind
					//log.Printf("===removed address %s %s from service %s in %s", oldAddress.TargetRef.Name, serviceName, oldAddress.TargetRef.UID, serviceNameSpace)
					removeRelationship("ServiceTo"+endPointKind, "", string(oldAddress.TargetRef.UID), serviceName, oldAddress.TargetRef.Name, serviceNameSpace, getGephiTime(time.Now()))
				}
			}
		}

		//find added address
		for _, newSubset := range newEndpointObj.Subsets {
			for _, newAddress := range newSubset.Addresses {
				found := false
				for _, oldSubset := range oldEndpointObj.Subsets {
					for _, oldAddress := range oldSubset.Addresses {
						if newAddress.TargetRef.Name == oldAddress.TargetRef.Name {
							found = true
						}
					}
				}
				if !found {
					endPointKind := newAddress.TargetRef.Kind
					//log.Printf("===added address %s %s to service %s in %s", newAddress.TargetRef.Name, newAddress.TargetRef.UID, serviceName, serviceNameSpace)
					addRelationship("ServiceTo"+endPointKind, "", string(newAddress.TargetRef.UID), serviceName, newAddress.TargetRef.Name, serviceNameSpace, getGephiTime(time.Now()))
				}
			}
		}
	case *corev1.Pod:
		newPodObj := iNewObj.(*corev1.Pod)
		oldPodObj := iOldObj.(*corev1.Pod)
		if newPodObj.Status.Phase != oldPodObj.Status.Phase && newPodObj.Status.Phase == "Running" {
			//log.Printf("POD STATUS CHANGED: %v %v %v -> %v\n", newPodObj.Name, newPodObj.Namespace, newPodObj.Status.Phase, oldPodObj.Status.Phase)
			nodeName, nodeId := lookupNode(newPodObj.Status.HostIP, false)
			if nodeId == "" {
				log.Printf("node not found again - %v", newPodObj.Name)
			}
			addRelationship("PodToNode", string(newPodObj.ObjectMeta.GetUID()), nodeId, newPodObj.ObjectMeta.GetName(), nodeName, newPodObj.ObjectMeta.GetNamespace(), getGephiTime(time.Now()))

		}
	}
}

func getGephiTime(tm time.Time) string {
	return strconv.FormatInt(tm.Unix(), 10) + "000"
}

func outputEvent(eventAction string, eventType string, eventData string) {
	log.Printf("%v,%v,%v", eventAction, eventType, eventData)
}

func addRelationship(relationshipKind string, relationshipSrcUid string, relationshipTgtUid string, srcName string, tgtName string, relationshipNamespace string, startTime string) {

	re := relationshipEvent{
		SrcUid:    relationshipSrcUid,
		TgtUid:    relationshipTgtUid,
		SrcName:   srcName,
		TgtName:   tgtName,
		Namespace: relationshipNamespace,
		Kind:      relationshipKind,
	}

	if strings.HasPrefix(relationshipKind, "ServiceTo") && relationshipSrcUid == "" {
		relationshipsMissingService = append(relationshipsMissingService, re)
		addRelationshipsWithMissingService()
		return
	}

	if strings.HasPrefix(relationshipKind, "NamespaceTo") && relationshipSrcUid == "" {
		relationshipsMissingNamespace = append(relationshipsMissingNamespace, re)
		addRelationshipsWithMissingNamespace()
		return
	}

	jsonData, err := json.Marshal(re)
	if err != nil {
		log.Println(err)
	}
	outputEvent("ADD", "Relationship", string(jsonData))
}

func removeRelationship(relationshipKind string, relationshipSrcUid string, relationshipTgtUid string, srcName string, tgtName string, relationshipNamespace string, endTime string) {

	rSrcUid := relationshipSrcUid

	re := relationshipEvent{
		SrcUid:    rSrcUid,
		TgtUid:    relationshipTgtUid,
		SrcName:   srcName,
		TgtName:   tgtName,
		Namespace: relationshipNamespace,
		Kind:      relationshipKind,
	}

	if strings.HasPrefix(relationshipKind, "ServiceTo") && relationshipSrcUid == "" {
		for _, sr := range serviceResources {
			//if sr.deleted == true {
			if sr.Name == re.SrcName && sr.Namespace == re.Namespace {
				re.SrcUid = sr.Uid
			}
			//}
		}
	}

	jsonData, err := json.Marshal(re)
	if err != nil {
		log.Println(err)
	}
	outputEvent("DELETE", "Relationship", string(jsonData))
}

func addRelationshipsWithMissingService() {

	var stillMissingServices []relationshipEvent

	for _, sr := range serviceResources {
		if sr.deleted == false {
			stillMissingServices = stillMissingServices[:0]
			for _, ms := range relationshipsMissingService {
				if sr.Name == ms.SrcName && sr.Namespace == ms.Namespace {
					ms.SrcUid = sr.Uid
					jsonData, err := json.Marshal(ms)
					if err != nil {
						log.Println(err)
					}
					outputEvent("ADD", "Relationship", string(jsonData))
				} else {
					stillMissingServices = append(stillMissingServices, ms)
				}
			}
			relationshipsMissingService = stillMissingServices
		}
	}
}

func addRelationshipsWithMissingNamespace() {

	var stillMissingNamespaces []relationshipEvent

	for _, nr := range namespaceResources {
		stillMissingNamespaces = stillMissingNamespaces[:0]
		for _, mn := range relationshipsMissingNamespace {
			if nr.Name == mn.Namespace {
				mn.SrcUid = nr.Uid
				jsonData, err := json.Marshal(mn)
				if err != nil {
					log.Println(err)
				}
				outputEvent("ADD", "Relationship", string(jsonData))
			} else {
				stillMissingNamespaces = append(stillMissingNamespaces, mn)
			}
		}
		relationshipsMissingNamespace = stillMissingNamespaces

	}
}

func getNamespaceResouceUid(namespaceName string, includeDeleted bool) string {
	var returnUid string
	for _, namespace := range namespaceResources {
		if namespace.Name == namespaceName {
			if !namespace.deleted || includeDeleted {
				returnUid = namespace.Uid
			}
		}
	}
	return returnUid
}

func lookupNode(hostip string, includeDeleted bool) (string, string) {
	var returnName string
	var returnUid string
	for _, node := range nodeResources {
		if node.Hostip == hostip {
			if !node.deleted || includeDeleted {
				returnUid = node.Uid
				returnName = node.Name
			}
		}
	}
	return returnName, returnUid
}

func lookupPod(podName string, podNamespace string, includeDeleted bool) podResource {
	var returnPod podResource
	for _, pod := range podResources {
		if pod.Name == podName && pod.Namespace == podNamespace {
			if includeDeleted {
				returnPod = pod
			} else {
				if pod.deleted != true {
					returnPod = pod
				}
			}
		}
	}
	return returnPod
}

func getK8sClient(configLocation string) (kubernetes.Interface, metricsclient.Interface, error) {

	kubeconfig := filepath.Clean(configLocation)
	config, err := clientcmd.BuildConfigFromFlags("", kubeconfig)
	if err != nil {
		log.Fatal(err)
	}
	kubeclientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return nil, nil, err
	}
	metricsclientset, err := metricsclient.NewForConfig(config)
	if err != nil {
		return nil, nil, err
	}
	return kubeclientset, metricsclientset, nil
}
